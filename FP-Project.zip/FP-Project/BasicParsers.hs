-- Add your names and student numbers to the following lines. Do not change anything else on these lines, since they are parsed.
-- Student 1: Your Name (sxxxxxxx)
-- Student 2: Second student (syyyyyyy)
-- Student 3: Third student (szzzzzzz)

module BasicParsers where

import Control.Applicative
import Data.Char
import Test.QuickCheck
import PComb

